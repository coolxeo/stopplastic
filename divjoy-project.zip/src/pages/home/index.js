import React from "react";
import HeroSection from "./../../components/HeroSection";
import WhyStopPlastic2 from "./../../components/WhyStopPlastic2";
import ClientsSection from "./../../components/ClientsSection";
import TestimonialsSection from "./../../components/TestimonialsSection";
import CtaSection from "./../../components/CtaSection";
import { useRouter } from "./../../util/router.js";
import "./styles.scss";

function HomePage(props) {
  const router = useRouter();

  return (
    <>
      <HeroSection
        color="primary"
        size="large"
        title="Reward plastic free initiatives and be a Patron"
        subtitle="Help projects and organisations to end with the plastic problem"
        buttonText="Browse Projects"
        buttonOnClick={() => {
          router.push("/pricing");
        }}
      />
      <WhyStopPlastic2
        color="white"
        size="medium"
        title="Why Stop Plastic?"
        subtitle="To reward good actions that help the world get rid of plastic"
      />
      <ClientsSection
        color="light"
        size="medium"
        title="You're in good company"
        subtitle=""
      />
      <TestimonialsSection
        color="white"
        size="medium"
        title="Here's what people are saying"
        subtitle=""
      />
      <CtaSection
        color="primary"
        size="medium"
        title="Ready to get started?"
        subtitle=""
        buttonText="Get Started"
        buttonOnClick={() => {
          router.push("/pricing");
        }}
      />
    </>
  );
}

export default HomePage;
